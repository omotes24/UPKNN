Technical appendix of the submission "Upright kNN" (anonymous).

- supplementary.pdf: the supplementary material (protocol details, all pairs, FPR95, ablations, mirror test, ImageNet tables, EuroSAT).
- README.md and the folders: code (GPU side, exactly as run), protocols (each written before its evaluation; FREEZE_UKNN.md5 with the
  checksums recorded before the final evaluation, verified by tools/check_freeze.py), benchmark definitions (runs/ok, eu/runs/jobs),
  analysis scripts and the result files of the paper (paper/gen/data).
- "PriorE" is an earlier detector of the authors, renamed for anonymity; it is not part of the submission. Because of this
  renaming, tools/check_freeze.py reports protocols/PROTOCOL_UKNN.md as different from its recorded checksum (the code files match);
  the non-anonymous release verifies all six files.
