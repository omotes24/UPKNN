Technical appendix of the submission "Neighbours and Orientation: Out-of-Distribution Detection with Frozen Diffusion
Features" (anonymous; the detector is called Upright kNN).

- supplementary.pdf: the supplementary material (protocol details, comparison methods, the proof of Proposition 2, the weight
  sweep, the two-notions analysis with its controls, all pairs, FPR95, ablations, the mirror test, the ImageNet tables incl. the
  bank-size and resampling controls, fusions, CSI, EuroSAT / chest X-rays / histology / rotation-trained generators, compute).
- README.md and the folders: code (GPU side, exactly as run), protocols (each written before its evaluation; FREEZE_UKNN.md5 with the
  checksums recorded before the final evaluation, verified by tools/check_freeze.py), benchmark definitions (runs/ok, eu/runs/jobs),
  analysis scripts and the result files of the paper (paper/gen/data).
- "PriorE" is an earlier detector of the authors, renamed for anonymity; it is not part of the submission. Because of this
  renaming, tools/check_freeze.py reports protocols/PROTOCOL_UKNN.md as different from its recorded checksum (the code files match);
  the non-anonymous release verifies all six files.
